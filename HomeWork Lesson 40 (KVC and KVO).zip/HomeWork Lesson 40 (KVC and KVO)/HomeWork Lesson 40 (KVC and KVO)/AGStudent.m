//
//  AGStudent.m
//  HomeWork Lesson 40 (KVC and KVO)
//
//  Created by Anton Gorlov on 04.07.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGStudent.h"

@interface AGStudent ()

@end

typedef enum {
    
    AGGenderSegmentControlMale,
    AGGenderSegmentControlFemale

} AGGenderSegmentControl; //gender

typedef enum {
    
    AGGradeStudentsTwo,
    AGGradeStudentsThree,
    AGGradeStudentsFour,
    AGGradeStudentsFive

} AGGradeStudents; //grade

typedef enum {
    
    AGTextFieldFirstName,
    AGTextFieldLastName,
    AGTextFieldDateOfBirth

} AGTextField;
@implementation AGStudent

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.firstName becomeFirstResponder];
    
}

#pragma mark - UITextFieldDelegate


- (BOOL)textFieldShouldReturn:(UITextField *)textField {

    
    for (int i = 0; i < [self.textCollectionField count] - 1; i++) {
        
        if (!([textField isEqual:[self.textCollectionField objectAtIndex:i]])) {
            
            [textField resignFirstResponder];
            
        }else  {
            
            [[self.textCollectionField objectAtIndex:i + 1] becomeFirstResponder];
            
        }
    }
    
    /*
    if ([textField isEqual:self.firstName]) {
        
        [self.lastName becomeFirstResponder];
        
    }
    
    if ([textField isEqual:self.lastName]) {
        
        [self.dateOfBirth becomeFirstResponder];
        
    }else {
    
        [textField resignFirstResponder];
        
    }
  */
    return NO;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
  
    switch (textField.tag) {
        case AGTextFieldFirstName:
            [self scriptFirstNameField:textField
                         shouldChangeCharactersInRange:range
                         replacementString:string];
            return NO;
            break;
            
            case AGTextFieldLastName:
            
            [self scriptLastNameField:textField
                        shouldChangeCharactersInRange:range
                        replacementString:string];
            return NO;
            break;
            
        case AGTextFieldDateOfBirth:
            
            [self scriptDateOfBirthField:textField
                       shouldChangeCharactersInRange:range
                       replacementString:string];
            return NO;
            break;
            
        default:
            break;
    }
    /*
    
    NSCharacterSet *validationSet = [[NSCharacterSet letterCharacterSet]invertedSet];
    
    NSArray *components = [string componentsSeparatedByCharactersInSet:validationSet];
    
    if ([components count] > 1) {
        
        return NO;
    }

    */
    return YES;
}


- (BOOL) scriptFirstNameField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {

    
    NSCharacterSet *validationName = [NSCharacterSet characterSetWithCharactersInString:@"@!#$%^?&,.<>""''()+-:;{}[]|/*//\\ 0123456789"];
    
    NSArray *components = [string componentsSeparatedByCharactersInSet:validationName];
    
    if ([components count] > 1) {
        
        return NO;
    }

    NSString *nameResultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if ([nameResultString length] > 15) {
        
        return NO;
    }
    
    textField.text = nameResultString;
  
    return NO;
}

- (BOOL) scriptLastNameField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {

    NSCharacterSet *validationSurname = [NSCharacterSet characterSetWithCharactersInString:@"@!#$%^?&,.<>""''()+-:;{}[]|/*//\\ 0123456789"];
    
    NSArray *components = [string componentsSeparatedByCharactersInSet:validationSurname];
    
    if ([components count] > 1) {
        
        return NO;
    }
    
    NSString *surnameResultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if ([surnameResultString length] > 18) {
        
        return NO;
    }
    
    textField.text = surnameResultString;
    
    return NO;
}

- (BOOL) scriptDateOfBirthField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {

    NSCharacterSet *validationdateOfBirth = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    NSArray *components = [string componentsSeparatedByCharactersInSet:validationdateOfBirth];
    
    if ([components count] > 1) {
        
        return NO;
    }
    
    NSString *dateOfBirthResultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if ([dateOfBirthResultString intValue] < 18) {
        
        textField.text = dateOfBirthResultString;
        
        return NO;
        
    }else if ([dateOfBirthResultString intValue] > 100) {
    
        return NO;
        
    }else {
    
      textField.text = dateOfBirthResultString;
        
    }
    
    return NO;
}
#pragma mark - Actions
- (IBAction)actionTextChanged:(UITextField *)sender {
    
    NSLog(@"actionTextChanged: %@",sender.text);
}

- (IBAction)actionValueChanged:(id)sender {
    
  
    if (self.gender.selectedSegmentIndex == AGGenderSegmentControlMale) {
        
        NSLog(@"Male");
        
    } else if (self.gender.selectedSegmentIndex == AGGenderSegmentControlFemale) {
    
        NSLog(@"Female");
    }
  
   
    if (self.grade.selectedSegmentIndex == AGGradeStudentsTwo) {
        
        NSLog(@"2!");
        
    }else if (self.grade.selectedSegmentIndex == AGGradeStudentsThree) {
    
        NSLog(@"3");
        
    }else {
        
        NSLog(@"4");
    }
  
    if (self.grade.selectedSegmentIndex == AGGradeStudentsFive) {
        
        NSLog(@"5!");
        
    }
}
@end
