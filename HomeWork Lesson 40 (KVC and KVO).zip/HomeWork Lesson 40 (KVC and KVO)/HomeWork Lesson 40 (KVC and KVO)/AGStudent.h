//
//  AGStudent.h
//  HomeWork Lesson 40 (KVC and KVO)
//
//  Created by Anton Gorlov on 04.07.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGStudent : UITableViewController <UITextFieldDelegate>


@property (weak, nonatomic) IBOutlet UITextField *firstName;
@property (weak, nonatomic) IBOutlet UITextField *lastName;
@property (weak, nonatomic) IBOutlet UITextField *dateOfBirth;
@property (weak, nonatomic) IBOutlet UISegmentedControl *gender;
@property (weak, nonatomic) IBOutlet UISegmentedControl *grade; //оценка
@property (strong, nonatomic) IBOutletCollection(UITextField) NSArray *textCollectionField;

- (IBAction)actionTextChanged:(UITextField *)sender;
- (IBAction)actionValueChanged:(id)sender;


@end
