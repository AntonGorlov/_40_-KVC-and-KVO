//
//  ViewController.h
//  HomeWork Lesson 40 (KVC and KVO)
//
//  Created by Anton Gorlov on 01.07.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

