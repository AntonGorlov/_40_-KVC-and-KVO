//
//  AGStudent.m
//  KVC and KVO (Lesson 40)
//
//  Created by Anton Gorlov on 29.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGStudent.h"

@implementation AGStudent

//по умолчанию срабатывает synthesize и он соз геттер и сеттер

- (void) setName:(NSString *)name { //переопределяем

    _name = name;  //чтобы не потерять имя,обращаемся к @property на прямую,устанавливаем (Смотри урок 4)
    
    NSLog(@"Student setName: %@",name);
}

- (void) setAge:(NSInteger)age {

    _age = age;
    
     NSLog(@"Student setAge: %ld", age);
}

//перепишем "description" ,чтобы было легче "дебажить", у каждого обьекта есть метод "description",срабатвает,когда хотим распечатать обьект (см первые уроки или ищи в группе iOS VK)
- (NSString*) description {

    return [NSString stringWithFormat:@"Student: %@ years :%ld",self.name , self.age];
}

//У KVC есть опасность,что мы не правильно введем название @property или будет отсутствие ключа,то App упадет,чтобы этого не было можно переопределить метод
- (void) setValue:(id)value forUndefinedKey:(NSString *)key { //Для Сеттера ,смотри тетрадь!

    NSLog(@"setValueforUndefinedKey");

}

- (id) valueForUndefinedKey:(NSString *)key { //для геттера

    NSLog(@"valueForUndefinedKey");

    return nil;
}

//Делаем тогда, когда KVO не работает сам по себе.Observer не будет знать,его нужно предупредить.

- (void) changeName {
    [self willChangeValueForKey:@"name"]; //позволяет информировать Observer, даже если меняем iVar (хотим изменить свойство "name")
    
    _name = @"FakeName"; //если здесь использовать не сеттер "self.name", а iVar "_name" ,то Observer вызван не будет,он не знает что изменилось
    
    [self didChangeValueForKey:@"name"]; //закончили изменять "name"
}
#pragma mark -Validation
/*
 
- (BOOL) validateValue:(inout id  _Nullable __autoreleasing *)ioValue forKey:(NSString *)inKey error:(out NSError * _Nullable __autoreleasing *)outError {

    if ([inKey isEqualToString:@"name"]) { //если изменяем наш "name" хотим проверить для имени
        
        NSString *newName =*ioValue; //берем обьект по этому указателю
        
        if (![newName isKindOfClass:[NSString class] ]) { // если не строка
            
            *outError = [[NSError alloc] initWithDomain:@"Not string" code:123 userInfo:nil]; //соз ошибку,код на фонарь ставим
            
            return NO; //не разрешаем
        }
        
        if ([newName rangeOfString:@"1"].location != NSNotFound) { //если это строка,и она содержит еденицу,то
            
            *outError = [[NSError alloc] initWithDomain:@"Has number" code:324 userInfo:nil];
            return NO;
        }
    }

    return YES;
}
*/

/*
//закоментируем метод - (BOOL) validateValue: чтобы работал этот.
//так же само как для property "name" соз метод setName: так же само есть такой для валидации

-(BOOL) validateName:(inout id *)ioValue error:(out NSError **)outError {
    
    NSLog(@"AAA");
    return YES; //вместо того чтобы иметь один метод - (BOOL) validateValue:! в котором проверяем каждый property.Можем для каждого property соз личный метод.
}
*/ 
@end
