//
//  AGGroup.h
//  KVC and KVO (Lesson 40)
//
//  Created by Anton Gorlov on 30.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGGroup : NSObject

//соз массив студентов,чтобы понять как работает KVC
@property (strong,nonatomic) NSArray *students;


//наша группа это NSArray,а не MutableArray (изменяемый массив),но можно изменить с помощью mutableArrayValueForKey
@end
