//
//  AppDelegate.m
//  KVC and KVO (Lesson 40)
//
//  Created by Anton Gorlov on 29.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "AGStudent.h"
#import "AGGroup.h"

@interface AppDelegate ()

@property (strong, nonatomic) AGStudent* student; //сделаем @property,чтобы не пропадал

//расмотрим операцию по ключам KVC
@property (strong, nonatomic) NSArray *groups;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    /*
    AGStudent *student = [[AGStudent alloc]init];
    
    [student addObserver:self       //addObserver будет наш delegate
             forKeyPath:@"name"    //смотреть изменения будем у name
             options:NSKeyValueObservingOptionNew |NSKeyValueObservingOptionOld //можем следить за тем,что быдет приходить.New и Old  значение
             context:NULL]; //context не надо,можно nil
    
    student.name = @"Ivan";
    student.age = 24;
    
    NSLog(@"Description %@",student); //если пишем "student",то description вызывается автоматически
    
    [student setValue:@"Petro" forKey:@"name"]; //устанавливаем имя, а ключ - это (грубо говоря) название property
    [student setValue:@26 forKey:@"age"];      //@ -это NSNumber можно так:[NSNumber numberWihtInteger:25]
    
    NSLog(@"name1 = %@ , name2 = %@",student.name,[student valueForKey:@"name"]); //Читаем (типо геттера) 1-й способ читает по геттеру,2-й способ по valueForKey
    NSLog(@"%@",student);
    

    self.student = student; //установим @property
    
    [student changeName];
 */
    
    AGStudent* student1 = [[AGStudent alloc]init]; //соз 4 студента,чтобы понять как работает KVC
    student1.name = @"Sasha";
    student1.age = 7;
    
    AGStudent* student2 = [[AGStudent alloc]init];
    student2.name = @"Vova";
    student2.age = 20.f;
    
    AGStudent* student3 = [[AGStudent alloc]init];
    student3.name = @"Bogdan";
    student3.age = 24.f;
    
    AGStudent* student4 = [[AGStudent alloc]init];
    student4.name = @"Karina";
    student4.age = 17;
    
    AGGroup *group1 = [[AGGroup alloc]init];
    group1.students = @[student1, student2, student3, student4];
    
    /*
    NSLog(@"%@",group1.students);
    
    NSMutableArray *array =[group1 mutableArrayValueForKey:@"students"]; //Изменяем обычный NSArray через MutableArray по ключу берем не обьект,а берем MutableArray.
    
    [array removeLastObject];
    
    NSLog(@"%@",array);
    */
    /*
    self.student = student1;
    NSLog(@"name = %@", [self valueForKeyPath:@"student"]); //KeyPath -это путь по всем property
    
    
    //Validation
    
    //NSString *name = @"Batman";
    NSNumber *name =@7;
    NSError *error = nil;
    
    if (![self.student validateValue:&name //проверяем можно ли нашему обьекту Student по ключу "name" установить имя @"Batman""
                              forKey:@"name"
                               error:&error]) { //если возвращает нет,то распечатаем ошибку.
       // Как проверить в нашем студенте?СМОТРИ AGStudent.m метод - (BOOL) validateValue:
        NSLog(@"%@",error);
    }
    */
    
    
    
    
    AGStudent* student5 = [[AGStudent alloc]init];
    student5.name = @"Jula";
    student5.age = 23;
    
    AGStudent* student6 = [[AGStudent alloc]init];
    student6.name = @"Marina";
    student6.age = 25;
    
    AGGroup *group2 = [[AGGroup alloc]init ];
    group2.students = @[student5, student6];
    
    self.groups = @[group1,group2]; //соз массив групп,заполним
    
    NSLog(@"groups count:%@",[self valueForKeyPath:@"groups.@count"]);//выводим количество элементов (групп) или [self.groups valueForKeyPath:@"@count"])
    
    //Обьединим всех студентов
    
    NSArray *allStudents = [self.groups valueForKeyPath:@"@distinctUnionOfArrays.students"];
    
    NSLog(@"all students:%@",allStudents);
    
    NSNumber *minAge = [allStudents valueForKeyPath:@"@min.age"];
    NSNumber *maxAge = [allStudents valueForKeyPath:@"@max.age"];
    NSNumber *sumAge = [allStudents valueForKeyPath:@"@sum.age"];
    NSNumber *avgAge = [allStudents valueForKeyPath:@"@avg.age"];
    
    
    NSLog(@"minAge %@",minAge);
    NSLog(@"maxAge %@",maxAge);
    NSLog(@"sumAge %@",sumAge);
    NSLog(@"avgAge %@",avgAge);
    
    //выводим массив всех имен (обьединяем обьекты) Не сортирует!
    
    NSArray *allNames = [allStudents valueForKeyPath:@"@distinctUnionOfObjects.name"];
    
    NSLog(@"all names :%@",allNames);
    
    return YES;
}

#pragma mark -Observing

//Метод,который следит за всем.Будет вызываться когда меняется какое-то property (если добавим на property Observer)
- (void) observeValueForKeyPath:(NSString *)keyPath
                       ofObject:(id)object
                         change:(NSDictionary<NSString *,id> *)change
                        context:(void *)context {

NSLog(@"\n observeValueForKeyPath:%@ \n ofObject: %@ \n change:%@",keyPath,object,change);
    
  

    //keyPath - изменение по ключу "name"
    //object (в примере -это студент Алекс)
   //change - говорит какого типа это уведомление (какое новое значение и какое старое)
    
    
   // id value = [change objectForKey:NSKeyValueChangeNewKey]; //можно еще взять новое значение,чтобы не обращаться к обьекту
}

- (void) dealloc { //если регелись,то должны и отписаться

    [self.student removeObserver:self forKeyPath:@"name"];
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
