//
//  ViewController.h
//  KVC and KVO (Lesson 40)
//
//  Created by Anton Gorlov on 29.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

